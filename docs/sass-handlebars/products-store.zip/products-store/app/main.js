$(function () {
    $('header').html(App.templates.header());
    $('nav').html(App.templates.nav());
    $('footer').html(App.templates.footer());

    var hash = window.location.hash;

    switch (hash) {
        case '#clients':
            $.getJSON('data/clients.json', function (data) {
                $('main').html(App.templates.clients({ clients: data }));
            });
            break;
        default:
            $.getJSON('data/products.json', function (data) {
                $('main').html(App.templates.products({ products: data }));
            });
            break;
    }
});
