var gulp = require('gulp');
var sass = require('gulp-sass');
var wrap = require('gulp-wrap');
var declare = require('gulp-declare');
var concat = require('gulp-concat');
var handlebars = require('gulp-handlebars');
var serve = require('gulp-serve');

gulp.task('sass', function () {
    return gulp.src('./styles/**/main.scss')
        .pipe(sass().on('error', sass.logError))
        .pipe(gulp.dest('./'));
});

gulp.task('sass:watch', function () {
    gulp.watch('./styles/**/main.scss', ['sass']);
});

gulp.task('templates', function () {
    return gulp.src('./templates/*.hbs')
        .pipe(handlebars())
        .pipe(wrap('Handlebars.template(<%= contents %>)'))
        .pipe(declare({
            namespace: 'App.templates',
            noRedeclare: true, // Avoid duplicate declarations
        }))
        .pipe(concat('templates.js'))
        .pipe(gulp.dest('./'));
});

gulp.task('templates:watch', function () {
    gulp.watch('./templates/*.hbs', ['templates']);
});

gulp.task('serve', serve('./'));

gulp.task('default', ['sass', 'templates', 'sass:watch', 'templates:watch', 'serve']);
