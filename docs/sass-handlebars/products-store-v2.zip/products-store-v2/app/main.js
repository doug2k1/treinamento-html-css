$(function () {
    var section = window.location.search.substring(1) || 'home';

    $('header').html(App.templates.header());
    $('nav').html(App.templates.nav({ section: section }));
    $('footer').html(App.templates.footer());

    switch (section) {
        case 'clients':
            $.getJSON('data/clients.json', function (data) {
                $('main').html(App.templates.clients({ clients: data }));
            });
            break;
        case 'products':
            $.getJSON('data/products.json', function (data) {
                $('main').html(App.templates.products({ products: data }));
            });
            break;
        default: // home
            $('main').html(App.templates.home());
            break;
    }
});
