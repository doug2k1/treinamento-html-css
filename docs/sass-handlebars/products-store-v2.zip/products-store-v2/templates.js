this["App"] = this["App"] || {};
this["App"]["templates"] = this["App"]["templates"] || {};
this["App"]["templates"]["clients"] = Handlebars.template({"1":function(depth0,helpers,partials,data) {
    var stack1, helper, alias1=helpers.helperMissing, alias2="function", alias3=this.escapeExpression;

  return "            <tr>\n                <th>"
    + alias3(((helper = (helper = helpers.id || (depth0 != null ? depth0.id : depth0)) != null ? helper : alias1),(typeof helper === alias2 ? helper.call(depth0,{"name":"id","hash":{},"data":data}) : helper)))
    + "</th>\n                <td>"
    + alias3(((helper = (helper = helpers.first_name || (depth0 != null ? depth0.first_name : depth0)) != null ? helper : alias1),(typeof helper === alias2 ? helper.call(depth0,{"name":"first_name","hash":{},"data":data}) : helper)))
    + "</td>\n                <td>"
    + alias3(((helper = (helper = helpers.last_name || (depth0 != null ? depth0.last_name : depth0)) != null ? helper : alias1),(typeof helper === alias2 ? helper.call(depth0,{"name":"last_name","hash":{},"data":data}) : helper)))
    + "</td>\n                <td>\n                    <a href=\"mailto:"
    + alias3(((helper = (helper = helpers.email || (depth0 != null ? depth0.email : depth0)) != null ? helper : alias1),(typeof helper === alias2 ? helper.call(depth0,{"name":"email","hash":{},"data":data}) : helper)))
    + "\">\n                        <span class=\"glyphicon glyphicon-envelope\"></span>\n                        "
    + alias3(((helper = (helper = helpers.email || (depth0 != null ? depth0.email : depth0)) != null ? helper : alias1),(typeof helper === alias2 ? helper.call(depth0,{"name":"email","hash":{},"data":data}) : helper)))
    + "\n                    </a>\n                </td>\n                <td>\n"
    + ((stack1 = helpers['if'].call(depth0,(depth0 != null ? depth0.active : depth0),{"name":"if","hash":{},"fn":this.program(2, data, 0),"inverse":this.program(4, data, 0),"data":data})) != null ? stack1 : "")
    + "                </td>\n                <td>"
    + alias3(((helper = (helper = helpers.gender || (depth0 != null ? depth0.gender : depth0)) != null ? helper : alias1),(typeof helper === alias2 ? helper.call(depth0,{"name":"gender","hash":{},"data":data}) : helper)))
    + "</td>\n            </tr>\n";
},"2":function(depth0,helpers,partials,data) {
    return "                        <span class=\"label label-primary\">Sim</span>\n";
},"4":function(depth0,helpers,partials,data) {
    return "                        <span class=\"label label-default\">Não</span>\n";
},"compiler":[6,">= 2.0.0-beta.1"],"main":function(depth0,helpers,partials,data) {
    var stack1;

  return "<h2>Clientes</h2>\n\n<table class=\"table table-bordered table-striped\">\n    <thead>\n        <tr>\n            <th>ID</th>\n            <th>Nome</th>\n            <th>Sobrenome</th>\n            <th>E-mail</th>\n            <th>Ativo</th>\n            <th>Sexo</th>\n        </tr>\n    </thead>\n    <tbody>\n"
    + ((stack1 = helpers.each.call(depth0,(depth0 != null ? depth0.clients : depth0),{"name":"each","hash":{},"fn":this.program(1, data, 0),"inverse":this.noop,"data":data})) != null ? stack1 : "")
    + "    </tbody>\n</table>\n\n\n\n\n\n\n\n\n\n\n<!---->\n";
},"useData":true});
this["App"]["templates"]["footer"] = Handlebars.template({"compiler":[6,">= 2.0.0-beta.1"],"main":function(depth0,helpers,partials,data) {
    return "<div class=\"container-fluid\">\n    &copy; Bootstrap Store\n</div>\n";
},"useData":true});
this["App"]["templates"]["header"] = Handlebars.template({"compiler":[6,">= 2.0.0-beta.1"],"main":function(depth0,helpers,partials,data) {
    return "<div class=\"navbar navbar-inverse navbar-fixed-top\">\n    <div class=\"container-fluid\">\n        <a href=\"/\" class=\"navbar-brand\">\n            <span class=\"glyphicon glyphicon-shopping-cart\"></span>\n            Bootstrap Store</a>\n\n        <ul class=\"nav navbar-nav navbar-right\">\n            <li>Olá, Fulano!</li>\n            <li>\n                <a href=\"#\">\n                    Mensagens <span class=\"badge\">3</span>\n                </a>\n            </li>\n            <li>\n                <a href=\"#\">Sair</a>\n            </li>\n        </ul>\n    </div>\n</div>\n";
},"useData":true});
this["App"]["templates"]["home"] = Handlebars.template({"compiler":[6,">= 2.0.0-beta.1"],"main":function(depth0,helpers,partials,data) {
    return "home\n";
},"useData":true});
this["App"]["templates"]["nav"] = Handlebars.template({"compiler":[6,">= 2.0.0-beta.1"],"main":function(depth0,helpers,partials,data) {
    var helper;

  return "<ul class=\"nav nav-pills nav-stacked "
    + this.escapeExpression(((helper = (helper = helpers.section || (depth0 != null ? depth0.section : depth0)) != null ? helper : helpers.helperMissing),(typeof helper === "function" ? helper.call(depth0,{"name":"section","hash":{},"data":data}) : helper)))
    + "\">\n    <li class=\"menu-products\">\n        <a href=\"/?products\">\n            <span class=\"glyphicon glyphicon-gift\"></span>\n            Produtos\n        </a>\n    </li>\n    <li class=\"menu-clients\">\n        <a href=\"/?clients\">\n            <span class=\"glyphicon glyphicon-user\"></span>\n            Clientes\n        </a>\n    </li>\n</ul>\n";
},"useData":true});
this["App"]["templates"]["products"] = Handlebars.template({"1":function(depth0,helpers,partials,data) {
    var stack1, helper, alias1=helpers.helperMissing, alias2="function", alias3=this.escapeExpression;

  return "            <tr>\n                <th>"
    + alias3(((helper = (helper = helpers.id || (depth0 != null ? depth0.id : depth0)) != null ? helper : alias1),(typeof helper === alias2 ? helper.call(depth0,{"name":"id","hash":{},"data":data}) : helper)))
    + "</th>\n                <td>"
    + alias3(((helper = (helper = helpers.name || (depth0 != null ? depth0.name : depth0)) != null ? helper : alias1),(typeof helper === alias2 ? helper.call(depth0,{"name":"name","hash":{},"data":data}) : helper)))
    + "</td>\n                <td>"
    + alias3(((helper = (helper = helpers.price || (depth0 != null ? depth0.price : depth0)) != null ? helper : alias1),(typeof helper === alias2 ? helper.call(depth0,{"name":"price","hash":{},"data":data}) : helper)))
    + "</td>\n                <td>"
    + alias3(((helper = (helper = helpers.stock || (depth0 != null ? depth0.stock : depth0)) != null ? helper : alias1),(typeof helper === alias2 ? helper.call(depth0,{"name":"stock","hash":{},"data":data}) : helper)))
    + "</td>\n                <td>\n"
    + ((stack1 = helpers['if'].call(depth0,(depth0 != null ? depth0.active : depth0),{"name":"if","hash":{},"fn":this.program(2, data, 0),"inverse":this.program(4, data, 0),"data":data})) != null ? stack1 : "")
    + "                </td>\n                <td>"
    + alias3(((helper = (helper = helpers.sales || (depth0 != null ? depth0.sales : depth0)) != null ? helper : alias1),(typeof helper === alias2 ? helper.call(depth0,{"name":"sales","hash":{},"data":data}) : helper)))
    + "</td>\n                <td>"
    + alias3(((helper = (helper = helpers.brand || (depth0 != null ? depth0.brand : depth0)) != null ? helper : alias1),(typeof helper === alias2 ? helper.call(depth0,{"name":"brand","hash":{},"data":data}) : helper)))
    + "</td>\n                <td>\n"
    + ((stack1 = helpers['if'].call(depth0,(depth0 != null ? depth0.image : depth0),{"name":"if","hash":{},"fn":this.program(6, data, 0),"inverse":this.program(8, data, 0),"data":data})) != null ? stack1 : "")
    + "                </td>\n            </tr>\n";
},"2":function(depth0,helpers,partials,data) {
    return "                        <span class=\"label label-primary\">Sim</span>\n";
},"4":function(depth0,helpers,partials,data) {
    return "                        <span class=\"label label-default\">Não</span>\n";
},"6":function(depth0,helpers,partials,data) {
    var helper;

  return "                        <img src=\""
    + this.escapeExpression(((helper = (helper = helpers.image || (depth0 != null ? depth0.image : depth0)) != null ? helper : helpers.helperMissing),(typeof helper === "function" ? helper.call(depth0,{"name":"image","hash":{},"data":data}) : helper)))
    + "\" alt=\"\" class=\"product-image\" />\n";
},"8":function(depth0,helpers,partials,data) {
    return "                        <span class=\"glyphicon glyphicon-exclamation-sign no-image\"></span>\n";
},"compiler":[6,">= 2.0.0-beta.1"],"main":function(depth0,helpers,partials,data) {
    var stack1;

  return "<h2>Produtos</h2>\n\n<table class=\"table table-bordered table-striped\">\n    <thead>\n        <tr>\n            <th>ID</th>\n            <th>Nome</th>\n            <th>Preço</th>\n            <th>Estoque</th>\n            <th>Ativo</th>\n            <th>Vendas</th>\n            <th>Marca</th>\n            <th>Imagem</th>\n        </tr>\n    </thead>\n    <tbody>\n"
    + ((stack1 = helpers.each.call(depth0,(depth0 != null ? depth0.products : depth0),{"name":"each","hash":{},"fn":this.program(1, data, 0),"inverse":this.noop,"data":data})) != null ? stack1 : "")
    + "    </tbody>\n</table>\n";
},"useData":true});